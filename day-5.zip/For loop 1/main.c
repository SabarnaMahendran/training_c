#include <stdio.h>
int main() {
    for(int i=1; i<31; i++) {
        if(i%6 !=0 ) {
            printf("%d", i);
        } else {
            printf("%d\n", i);
        }
    }
    return 0;
}
