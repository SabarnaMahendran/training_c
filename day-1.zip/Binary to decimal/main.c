#include <stdio.h>

int main() {
    int b3 = 0;
    int b2 = 0;
    int b1 = 1;
    int b0 = 1;

    int decimal = (b3 * 8) + (b2 * 4) + (b1 * 2) + (b0 * 1);

    printf("Decimal value: %d", decimal);
    return 0;
}
