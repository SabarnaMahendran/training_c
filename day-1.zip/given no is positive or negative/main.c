#include <stdio.h>

int main()
{
    int num;
    {
        printf("enter the integer:");
        scanf("%d", &num);
    }
    if(num<0){
        printf("the integer is negative");
    }
    else if(num>0){
        printf("the integer is positive");
    }
    else
    {
        printf("the integer is zero");
    }
    
    
    return 0;
}
