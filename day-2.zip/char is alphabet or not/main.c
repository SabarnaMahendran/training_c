#include <stdio.h>

int main()
{
    char;
    printf("enter the alphabet:");
    scanf("%c", &char);
    if((c>='a' && c<='z') || (c<='A' && c<='Z'))
    {
        printf("%c ")
    }
    return 0;
}
 