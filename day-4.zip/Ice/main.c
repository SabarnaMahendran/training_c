#include <stdio.h>
void main()
{
    if (!printf("ICE"))
    {
        printf("ICE");
    }
    else
    {
        printf("CREAM");
    }
}