#include <stdio.h>
int main()
{
    int a = 10, b = 2, c = 6;
    int d = a - b ? a : b;
    printf("Value of c: %d\n", c);
    if (a >= b && a >= c)
        printf("a = %d is greater\n", a);
    else if (b >= a && b >= c)
        printf("b = %d is greater\n", b);
    else
        printf("c = %d is greater\n", c);
    return 0;
}
