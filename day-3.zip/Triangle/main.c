#include <stdio.h>
int main()
{
    int a, b, c;
    printf("Enter three sides of the triangle: ");
    scanf("%d %d %d", &a, &b, &c);
    if (a + b > c && b + c > a && c + a > b) {
        printf("The given sides form a triangle\n");
        if (a == b && b == c)
            printf("It is an equilateral triangle\n");
        else
            printf("It is not an equilateral triangle\n");
    } else {
        printf("The given sides do not form a triangle\n");
    }
    return 0;
}

